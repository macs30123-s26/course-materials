import boto3
import json
import os

import nltk 
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.probability import FreqDist
from nltk.util import ngrams

nltk.download('punkt', download_dir='/tmp/nltk_data')
nltk.download('stopwords', download_dir='/tmp/nltk_data')
nltk.download('averaged_perceptron_tagger', download_dir='/tmp/nltk_data')


def lambda_handler(event, context):
    # Ask Lambda to look for necessary models in the tmp file
    nltk.data.path.append("/tmp/nltk_data")

    s3_client = boto3.client('s3')
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(os.environ["TABLE_NAME"])

    message_body = json.loads(event['Records'][0]['body'])
    job_id = message_body['job_id']
    bucket = message_body['bucket']
    key = message_body['key']

    # fetch text file from S3
    response = s3_client.get_object(Bucket=bucket, Key=key)
    text = response['Body'].read().decode('utf-8')

    # text processing
    words = word_tokenize(text)
    stop_words = set(stopwords.words('english'))
    filtered_words = [
                        word.lower() for word in words
                        if word.lower() not in stop_words
                        and word.isalpha()
                    ]

    # getting text summary
    # vocab size
    vocabulary_size = len(set(filtered_words))

    # top 10 frequent words
    freq_dist = FreqDist(filtered_words)
    most_common_words = freq_dist.most_common(10)

    # variation of sentence lengths
    sentences = sent_tokenize(text)
    sentence_lengths = [len(sent) for sent in sentences]

    # lexical diversity of the whole text
    lexical_diversity = len(set(words)) / float(len(words))

    # most common n-grams
    bigrams = list(ngrams(filtered_words, 2))
    trigrams = list(ngrams(filtered_words, 3))
    bigram_freq = FreqDist(bigrams).most_common(3)
    trigram_freq = FreqDist(trigrams).most_common(3)

    summary = {
        'Vocabulary Size': vocabulary_size,
        'Most Common Words': most_common_words,
        'Sentence Length Variation': sentence_lengths,
        'Lexical Diversity': lexical_diversity,
        'Most Common Bigrams': bigram_freq,
        'Most Common Trigrams': trigram_freq
    }

    # Write results to back S3
    output_file_key = 'results_' + key
    s3_client.put_object(Bucket=bucket,
                         Key=output_file_key,
                         Body=json.dumps(summary))

    # Create DynamoDB entry
    table.put_item(Item={
        'job_id': job_id,
        'file_name': key,
        'file_location': bucket +'/'+key,
        'result_file': output_file_key
    })

    return {
        'statusCode': 200,
        'body': json.dumps('Successfully processed the text file.')
    }
